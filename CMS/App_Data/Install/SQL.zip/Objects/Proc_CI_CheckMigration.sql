SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE Proc_CI_CheckMigration(@name AS nvarchar(255))
AS
BEGIN
    IF EXISTS (SELECT 1 FROM CI_Migration WHERE MigrationName = @name)
	   RETURN 0

    INSERT INTO CI_Migration(MigrationName) VALUES(@name)
    RETURN 1
END


GO
