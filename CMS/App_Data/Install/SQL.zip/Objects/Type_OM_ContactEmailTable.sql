CREATE TYPE [dbo].[Type_OM_ContactEmailTable] AS TABLE(
	[Email] [nvarchar](254) NOT NULL,
	PRIMARY KEY CLUSTERED 
(
	[Email] ASC
)
)
GO
